<?php 
date_default_timezone_set('Asia/Jakarta');
define('HOST','localhost');
define('USER','root');
define('PASSWORD','');
define('DB','skripsi');

$con = mysqli_connect(HOST, USER, PASSWORD, DB) or die('Unable to connect');
