<?php

require "../config/connect.php";

$tgl = $_GET['date'];
$sql = mysqli_query($con, "select * from laporan p join users u on (p.id_user=u.id_user) join mesin i on (p.id_mesin=i.id_mesin) WHERE date(p.createDate)='$tgl' ORDER BY id_laporan ASC");

$respone = array();

while ($data = mysqli_fetch_array($sql)) {
    $respone[] = $data;
}

echo json_encode($respone);

?>