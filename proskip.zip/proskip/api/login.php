<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    $nip = $_POST['nip'];
    $password = $_POST['password'];

    $cek = "SELECT * FROM users WHERE nip='$nip' and password='$password'";
    $result = mysqli_fetch_array(mysqli_query($con, $cek));

    if (isset($result)) {
        $response['value']=1;
        $response['message']='Login berhasil';
        $response['nip']=$result['nip'];
        $response['nama']=$result['nama'];
        $response['email']=$result['email'];
        $response['jabatan']=$result['jabatan'];
        $response['level']=$result['level'];
        $response['id_user']=$result['id_user'];
        echo json_encode($response);
    } else {
        $response['value']=0;
        $response['message']="Login gagal";
        echo json_encode($response);
    }
}   

?>