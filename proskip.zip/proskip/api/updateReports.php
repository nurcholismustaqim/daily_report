<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response 		= array();
    $id_laporan 	= $_POST['id_laporan'];
    $judul 			= $_POST['judul'];
    $keterangan 	= $_POST['keterangan'];
    $image 			= $_FILES['image']['name'];
    // $createDate = $_POST['createDate'];
    $id_user 		= $_POST['id_user'];
    $id_mesin 		= $_POST['id_mesin'];


    //move image to images folder
    if($image !=''){

	    $imagePath = 'upload/'.$image; 
    	$tmp_name = $_FILES['image']['tmp_name']; 
	    move_uploaded_file($tmp_name, $imagePath);
	    $imgQ = "image='$image',";
	}else{
	    $imgQ = "";
	}

	if($id_mesin != ''){
		$mesin = ",id_mesin='$id_mesin' ";
	}else{
		$mesin = "";
	}

        $insert = "UPDATE laporan SET 
        judul='$judul',
        keterangan='$keterangan',
        $imgQ
        id_user='$id_user' $mesin
        WHERE id_laporan='$id_laporan'";
        if (mysqli_query($con, $insert)) {
            $response['value']=1;
            $response['message']="Berhasil di tambahkan";
            echo json_encode($response);
        } else {
            $response['value']=0;
            $response['message']="Gagal di tambahkan";
            echo json_encode($response);
        }
    }
