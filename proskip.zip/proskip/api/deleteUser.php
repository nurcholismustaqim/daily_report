<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    $id_user = $_POST['id_user'];

        $insert = "DELETE FROM users WHERE id_user = '$id_user'";
        if (mysqli_query($con, $insert)) {
            $response['value']=1;
            $response['message']="Berhasil di hapus";
            echo json_encode($response);
        } else {
            $response['value']=0;
            $response['message']="Gagal di hapus";
            echo json_encode($response);
        }
    }
