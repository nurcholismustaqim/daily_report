<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    $nip = $_POST['nip']; 
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $jabatan = $_POST['jabatan'];
    $level = $_POST['level'];
    $password = $_POST['password'];
    $id_user = $_POST['id_user']; 

        $insert = "UPDATE users SET 
        nip='$nip',
        nama='$nama',
        email='$email',
        jabatan='$jabatan',
        level='$level',
        password='$password' WHERE id_user='$id_user'";
        if (mysqli_query($con, $insert)) {
            $response['value']=1;
            $response['message']="Berhasil di tambahkan";
            echo json_encode($response);
        } else {
            $response['value']=0;
            $response['message']="Gagal di tambahkan";
            echo json_encode($response);
        }
    }
