<?php

require "../config/connect.php";

// if(isset($_POST["judul"])) {
//     $judul = $_POST["judul"];
// }
// else return;
// if(isset($_POST["keterangan"])) {
//     $keterangan = $_POST["keterangan"];
// }
// else return;
// if(isset($_POST["data"])) {
//     $data = $_POST["data"];
// }
// else return;
// if(isset($_POST["name"])) {
//     $name = $_POST["name"];
// }
// else return;
// if(isset($_POST["id_user"])) {
//     $id_user = $_POST["id_user"];
// }
// else return;
// if(isset($_POST["id_mesin"])) {
//     $id_mesin = $_POST["id_mesin"];
// }
// else return;

// $path = "upload/$name";

// $query = "INSERT INTO laporan VALUE (NULL,'$judul','$keterangan', '$path', now(),'$id_user','$id_mesin')";
//     file_put_contents($path,base64_decode($data));

//     $arr=[];
//     if (mysqli_query($con, $query)) {
    //                     $response['value']=1;
    //                     $response['message']="Berhasil di tambahkan";
    //                     echo json_encode($response);
    //                 } else {
        //                     $response['value']=0;
//                     $response['message']="Gagal di tambahkan";
//                     echo json_encode($response);
//                 }



if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    // $id_laporan = $_POST['id_laporan'];
    $judul = $_POST['judul'];
    $keterangan = $_POST['keterangan'];
    // $data = $_POST['data'];
    // $name = $_POST['name'];
    $image = $_FILES['image']['name'];
    
    // $createDate = $_POST['createDate'];
    $id_user = $_POST['id_user'];
    $id_mesin = $_POST['id_mesin'];
    $tgl = $_POST['tanggal'];
    $timestamp = date("Y-m-d", strtotime($tgl)).' '.date("H:i:s");
    
    $imagePath = 'upload/'.$image; 

    $tmp_name = $_FILES['image']['tmp_name']; 

    //move image to images folder
    move_uploaded_file($tmp_name, $imagePath);
    // $imagePath = "upload/$image";
    // $tmp_name = $_FILES['image']['tmp_name'];
    
    // move_uploaded_file($_FILES['image']['tymp_name'], $imagePath);
    
    // $path = "upload/$name";
    // $path = "upload/$image";

    
    // $insert = "INSERT INTO laporan VALUE (NULL,'$judul','$keterangan', '$image', now(),'$id_user','$id_mesin')";
    $query = "INSERT INTO laporan VALUE (NULL,'$judul','$keterangan', '$image', '$timestamp','$id_user','$id_mesin')";
    // file_put_contents($path,base64_decode($data));

    $arr=[];
            if (mysqli_query($con, $query)) {
                            $response['value']=1;
                            $response['message']="Berhasil di tambahkan";
                            echo json_encode($response);
                        } else {
                            $response['value']=0;
                            $response['message']="Gagal di tambahkan";
                            echo json_encode($response);
                        }
    } 

?>