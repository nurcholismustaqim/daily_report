<?php

require "../config/connect.php";


$sql = mysqli_query($con, "SELECT * FROM mesin");

$respone = array();

while ($data = mysqli_fetch_array($sql)) {
    $respone[] = $data;
}

echo json_encode($respone);

?>