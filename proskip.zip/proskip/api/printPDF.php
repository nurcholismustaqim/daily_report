<?php 
header("Content-Type:application/pdf");
header("Content-Disposition:attachment;filename=\"DailyReport.pdf\"");
session_start();

ob_start(); 

$uri = $_SERVER['HTTP_HOST'];;

require "../config/connect.php";
$tgl = $_GET['date'];  
$nama_spv = $_GET['spv'];  
 
function tanggal_indo($timestamp = '', $date_format = 'D, j M Y', $suffix = '') {

    if (trim ($timestamp) == '')

    {

            $timestamp = time ();

    }

    elseif (!ctype_digit ($timestamp))

    {

        $timestamp = strtotime ($timestamp);

    }

    $date_format = preg_replace ("/S/", "", $date_format);

    $pattern = array (

        '/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',

        '/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',

        '/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',

        '/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',

        '/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',

        '/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',

        '/April/','/June/','/July/','/August/','/September/','/October/',

        '/November/','/December/',

    );

    $replace = array (  
        'Senin,','Selasa,','Rabu,','Kamis,','Jumat,','Sabtu,','Minggu,', 
        'Senin,','Selasa,','Rabu,','Kamis,','Jumat,','Sabtu,','Minggu,', 
        'Januari ','Februari ','Maret ','April ','Juni ','Juli ','Agustus ','Sepember ','Oktober ','November ','Desember ',
        'Januari ','Februari ','Maret ','April ','Juni ','Juli ','Agustus ','Sepember ','Oktober ','November ','Desember ',

    );

    $date = date ($date_format, $timestamp);

    $date = preg_replace ($pattern, $replace, $date);

    $date = "{$date}";

    return $date;

} 


?> 





<html xmlns="http://www.w3.org/1999/xhtml">  

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 

<title>Report</title> 

 <style type="text/css">  

 	.batas{

 		margin-top: 100px;

 	} 

	.hed{

		font-size: 10px;

		font-weight: bold;

		line-height: 13px;

	}

	.th{

		font-size: 13px;

		text-align: center; 

    	border: 1px solid black;

    	padding: 5px;

    	 word-break: break-all;

	}

	.text7{

		font-size: 7px;

		text-align: center;

		padding: 1px;

	}

	.Content{

		font-size: 12px;

		text-align: left;

		padding: 3px; 

		 word-break: break-all;

	} 

	.namaContent{

		font-size: 9px;

		text-align: left;

		padding: 3px;

	}  

	.table{

    	border-collapse: collapse;
		table-layout: fixed; width: 100%
	}

	.nama_acc{

		font-weight: bold;

	}

	.warna{

		background-color: #7FC0FF; 

		color: #fff;

	}

	p{

		font-size: 14px;

		float: right;

		margin-left: 0px; 

		font-weight: bold;

	}

	.kiri{

		margin-left:  800px;

	}



	.kiri2{

		margin-left:  270px;

	}

	.center{

		text-align: center;

	} 
 .break {
    display: block;
    clear: both;
    page-break-after: always;
  }
  .wrap{
  	word-wrap: break-word;
  }
</style>

</head>

<body class="dotted">   
   
	<div >

		<h3 style="text-align: center;">DAILY REPORT</h3>
		<h4 style="text-align: center;"><?php echo tanggal_indo($tgl); ?></h4>
	

	</div> 

	<br>  
	 

	<br>

	<table class="table"  >

                    <thead>

                      <tr class="warna">

                        <th  class="th warna" width="5">No</th> 

                        <th  class="th warna" width="150">Nama</th> 
                        <th   class="th warna" width="150">Judul</th> 
                        <th  class="th warna" width="150">Keterangan</th> 
                        <th   class="th warna" width="140">Foto</th> 
 						</tr>
                    </thead>

                    <tbody>

                  <?php   
 
                  $tampil = mysqli_query($con, "SELECT a.*, b.`nama`, c.`nama_mesin` FROM laporan a LEFT JOIN users b ON a.`id_user`=b.`id_user` LEFT JOIN mesin c ON a.`id_mesin`=c.`id_mesin` WHERE DATE(a.`createDate`)='$tgl'");
                  if(mysqli_num_rows($tampil) == 0){  

                      echo "<tr><td colspan='3'>Tidak ada data!</td></tr>";

                    }else{   
                    	$no =1;

                      while ($q = mysqli_fetch_array($tampil)) {
                         

                    echo" <tr>

                          <td  class='th Content center'> $no </td>    
                          <td  class='th Content'> $q[nama] </td>  
                          <td  class='th Content'> $q[nama_mesin]<br>$q[judul] </td>  
                          <td  class='th Content wrap'> ".wordwrap($q['keterangan'],20,'<br/>',true)."</td>  
                          <td  class='th Content'><img width='120' height='120' src='upload/$q[image]'></td>  
                      		 
                          </tr>";  

                          $no++;  

		                    } 

		                  }  

                      ?> 
                    </tbody> 

                    	

                  </table>    
                  <br>
                  <br>
                  <br>
                  <table border="0" align="right">
                  	<tr> 
                  		<td  width="200"></td>
                  		<td width="200"></td>
                  		<td  width="200"><br></td>
                  	</tr>
                  	<tr> 
                  		

                  		<td><br><br><br></td> 
                  		<td><br><br><br></td> 
                  		<td><br><br><br></td> 
                  	</tr>
                  	 
                  	<tr>
                  		<td></td>
                  		<td  align="center" >
                  			Section Leader<br>
                  			<br>
                  			<br>
                  			<br>
                  			<br> 
                  			<br> 
                  		<?php echo $nama_spv; ?>
                  		<br>
                  		<br>
                  		<br>
                  		</td>
                  		<td></td>

                  	</tr>
                  </table>

<div class="break"></div>
 
</body>

</html> 

<?php

$filename="DailyReport_".$tgl.".pdf";  

$content = ob_get_clean();

	$content = '<page style="font-family: Arial">'. $content .'</page>';

	require_once('../html2pdf/html2pdf.class.php');

	try

	{ 

		$html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(12, 12, 3, 3));

		$html2pdf->setDefaultFont('Arial'); 

		$html2pdf->writeHTML($content, isset($_GET['vuehtml']));

		$html2pdf->Output($filename);

	}

	catch(HTML2PDF_exception $e) { echo $e; }

?>

 

				