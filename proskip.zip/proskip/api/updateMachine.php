<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    $no_mesin = $_POST['no_mesin']; 
    $nama_mesin = $_POST['nama_mesin'];
    $jenis = $_POST['jenis'];
    $area = $_POST['area'];
    $id_mesin = $_POST['id_mesin']; 

        $insert = "UPDATE mesin SET 
        no_mesin='$no_mesin',
        nama_mesin='$nama_mesin',
        jenis='$jenis',
        area='$area' WHERE id_mesin='$id_mesin'";
        if (mysqli_query($con, $insert)) {
            $response['value']=1;
            $response['message']="Berhasil di tambahkan";
            echo json_encode($response);
        } else {
            $response['value']=0;
            $response['message']="Gagal di tambahkan";
            echo json_encode($response);
        }
    }
