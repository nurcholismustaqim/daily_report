<?php

require "../config/connect.php";

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $response = array();
    $id_laporan = $_POST['id_laporan'];

        $insert = "DELETE FROM laporan WHERE id_laporan = '$id_laporan'";
        if (mysqli_query($con, $insert)) {
            $response['value']=1;
            $response['message']="Berhasil di hapus";
            echo json_encode($response);
        } else {
            $response['value']=0;
            $response['message']="Gagal di hapus";
            echo json_encode($response);
        }
    }
